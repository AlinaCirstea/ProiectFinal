package Selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class SeleniumHelper {
    WebDriver driver;
    WebDriverWait wait;
     @BeforeTest

    public void openBrowser(){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Bogdan\\Desktop\\Curs testare\\Testare Automata\\Java\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
    }

    public void logInApp(String email, String password){
        driver.get("http://lib.academiatestarii.ro/");
        driver.findElement(By.id("login")).click();
//        driver.findElement(By.id("login_email")).sendKeys("AlinaUserName68581@academiatestarii.ro");
//        driver.findElement(By.id("login_password")).sendKeys("testare1234");
        driver.findElement(By.id("login_email")).sendKeys(email);
        driver.findElement(By.id("login_password")).sendKeys(password);
        driver.findElement(By.xpath("//*[@type=\"submit\"]")).click();
        wait.until(ExpectedConditions.urlContains("dashboard"));
        Assert.assertEquals(driver.getCurrentUrl(), "http://lib.academiatestarii.ro/dashboard");
    }


    public void CheckLendBook(){
        driver.findElement(By.id("books")).click();
        wait.until(ExpectedConditions.urlContains("books"));
        driver.findElement(By.xpath("//*[@id=\"view_102\"]/strong")).click();
        wait.until(ExpectedConditions.urlContains("view"));
        Select select = new Select(driver.findElement(By.id("select_lender")));
        select.selectByIndex(3);
        driver.findElement(By.id("lend_book")).click();
        Assert.assertEquals(driver.findElement(By.id("available_books")).getText(), "Available Books: 4");
    }

    public void CreateInvalidBook(String email, String password){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Bogdan\\Desktop\\Curs testare\\Testare Automata\\Java\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://lib.academiatestarii.ro/");
        driver.findElement(By.id("login")).click();
        driver.findElement(By.id("login_email")).sendKeys(email);
        driver.findElement(By.id("login_password")).sendKeys(password);
        driver.findElement(By.xpath("//*[@type=\"submit\"]")).click();
        wait.until(ExpectedConditions.urlContains("dashboard"));
        Assert.assertEquals(driver.getCurrentUrl(), "http://lib.academiatestarii.ro/dashboard");
        driver.findElement(By.id("books")).click();
        wait.until(ExpectedConditions.urlContains("books"));
        driver.findElement(By.id("select_authors")).click();
        Select select = new Select(driver.findElement(By.id("select_authors")));
        select.selectByVisibleText(" Mark Twain ");
        driver.findElement(By.id("create_book")).click();
        System.out.println(driver.findElement(By.xpath("//*[@id=\"create_name\"]")).getAttribute("aria-invalid"));
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"create_name\"]")).getAttribute("aria-invalid"), "true");
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"create_total\"]")).getAttribute("aria-invalid"), "true");
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"create_available\"]")).getAttribute("aria-invalid"), "true");
        Assert.assertEquals(driver.findElement(By.xpath("//*[@id=\"create_id\"]")).getAttribute("aria-invalid"), "true");
    }

    public void DeleteBook(){
        driver.findElement(By.id("books")).click();
        wait.until(ExpectedConditions.urlContains("books"));
//        driver.findElement(By.xpath("//*[@id=\"view_102\"]/strong")).click();
//        wait.until(ExpectedConditions.urlContains("view"));
        driver.findElement(By.id("delete_102")).click();
        wait.until(ExpectedConditions.alertIsPresent());
        driver.switchTo().alert().accept();
//        Assert.assertEquals(ExpectedConditions.invisibilityOfElementLocated(By.id("view_102")), "element to no longer be visible: By.id: view_102");
    }

    public void CreateNewAuthor(String email, String password){
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Bogdan\\Desktop\\Curs testare\\Testare Automata\\Java\\chromedriver.exe");
        driver = new ChromeDriver();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.manage().window().maximize();
        driver.get("http://lib.academiatestarii.ro/");
        driver.findElement(By.id("login")).click();
        driver.findElement(By.id("login_email")).sendKeys(email);
        driver.findElement(By.id("login_password")).sendKeys(password);
        driver.findElement(By.xpath("//*[@type=\"submit\"]")).click();
        wait.until(ExpectedConditions.urlContains("dashboard"));
        Assert.assertEquals(driver.getCurrentUrl(), "http://lib.academiatestarii.ro/dashboard");
        driver.findElement(By.id("authors")).click();
        wait.until(ExpectedConditions.urlContains("authors"));
        driver.findElement(By.id("create_firstname")).sendKeys("Tom");
        driver.findElement(By.id("create_lastname")).sendKeys("Jerry");
        driver.findElement(By.id("create_id")).sendKeys("123");
        driver.findElement(By.id("create_author")).click();
    }

    public void VerifyEditBookApi(){
         driver.findElement(By.xpath("//*[@id=\"dashboard\"]")).click();
         wait.until(ExpectedConditions.urlContains("dashboard"));
         driver.findElement(By.xpath("//*[@id=\"books\"]")).click();
         wait.until(ExpectedConditions.urlContains("books"));


    }


}

