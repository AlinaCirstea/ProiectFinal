package Tests;

import API.*;
import Selenium.SeleniumHelper;
import org.testng.annotations.Test;

public class BookTest extends SeleniumHelper {
    CreateUserAPI userAPI= new CreateUserAPI();
    CreateAuthorAPI authorAPI = new CreateAuthorAPI();
    CreateBookAPI bookAPI = new CreateBookAPI();
    EditBookAPI editBookAPI = new EditBookAPI();
    ViewBookAPI viewBookAPI = new ViewBookAPI();

    @Test (priority = 1)
    public void UserAuthTests(){
        userAPI.createUser();
        logInApp(userAPI.emailCreated, userAPI.password);
        authorAPI.createAuthor(userAPI.idCreated, userAPI.emailCreated);
        bookAPI.createBook(userAPI.idCreated, userAPI.emailCreated);
        bookAPI.createBook(userAPI.idCreated, userAPI.emailCreated);
        CheckLendBook();
    }

    @Test (priority = 2)
   public void emptyBookTest(){
        CreateInvalidBook(userAPI.emailCreated, userAPI.password);
    }

    @Test(priority = 3)
    public void DeleteBookTest(){
    userAPI.createUser();
    bookAPI.createBook(userAPI.idCreated, userAPI.emailCreated);
    openBrowser();
    logInApp(userAPI.emailCreated, userAPI.password);
    DeleteBook();
    }

    @Test (priority = 4)
    public void EditBookTest(){
    userAPI.createUser();
    CreateNewAuthor(userAPI.emailCreated, userAPI.password);
    bookAPI.createBook(userAPI.idCreated, userAPI.emailCreated);
    editBookAPI.editBook(userAPI.idCreated, userAPI.emailCreated, userAPI.userName);
    VerifyEditBookApi();
    viewBookAPI.viewBookResponse(userAPI.idCreated, userAPI.emailCreated, userAPI.userName);
    }
    }




