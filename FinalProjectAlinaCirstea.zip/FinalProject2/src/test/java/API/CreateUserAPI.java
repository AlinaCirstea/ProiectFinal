package API;

import java.util.Random;

import static io.restassured.RestAssured.given;

public class CreateUserAPI {
    public int idCreated = generateNumber();
    public String emailCreated = generateEmail();
    public String password = "testare1234";
    public String userName = generateUserName();

    public void createUser(){
        given()
                .baseUri("http://35.205.170.236/api/v1/users/signup")
                .contentType("application/json")
                .body("{\n" +
                        "    \"username\": \"AlinaUserNameTest"+idCreated+"\",\n" +
                        "    \"name\": \"AlinaUserName"+idCreated+"\",\n" +
                        "    \"email\": \" " + emailCreated + " \",\n" +
                        "    \"password\": \""+password+"\",\n" +
                        "    \"password_confirmation\": \""+password+"\"\n" +
                        "}"
                )
                .post()
                .getBody().prettyPrint();
    }
    public int generateNumber(){
        return new Random().nextInt(99999);
    }
    public String generateEmail(){
        return "AlinaUserName"+idCreated+"@academiatestarii.ro";
    }
    public String generateUserName(){
        return "AlinaUserNameTest"+idCreated;
    }
}
