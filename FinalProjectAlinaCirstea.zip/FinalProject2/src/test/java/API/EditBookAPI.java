package API;

import static io.restassured.RestAssured.given;

public class EditBookAPI {
    public void editBook(int id, String email, String userName){
        given()
                .baseUri("http://35.205.170.236/api/v1/books/"+ userName+"/102")
                .auth().basic(email, "testare1234")
                .contentType("application/json")
                .body("{\n" +
                        "    \"name\": \"TestareAutomata\",\n" +
                        "    \"total\": \"2\",\n" +
                        "    \"available\": \"2\",\n" +
                        "    \"authors\": \"102\",\n" +
                        "    \"id\": 102\n" +
                        "}"
                )
                .put()
                .getBody().prettyPrint();
    }
}
