package API;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import org.openqa.selenium.devtools.v102.network.model.Request;

import static io.restassured.RestAssured.given;

public class CreateBookAPI {
    CreateUserAPI book = new CreateUserAPI();

    public void createBook(int id, String email) {
        given()
                .baseUri("http://35.205.170.236/api/v1/books/AlinaUserNameTest" + id)
                .auth().basic(email, "testare1234")
                .contentType("application/json")
                .body("{\n" +
                        "    \"name\": \"TestareAutomata\",\n" +
                        "    \"total\": \"4\",\n" +
                        "    \"available\": \"4\",\n" +
                        "    \"authors\": \"102\",\n" +
                        "    \"id\": 102\n" +
                        "}")
                .post()
                .getBody().prettyPrint();
    }

    public String generateBook() {
        return "TestareAutomata";
    }
}
