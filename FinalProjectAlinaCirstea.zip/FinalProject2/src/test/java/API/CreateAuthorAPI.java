package API;

import static io.restassured.RestAssured.given;

public class CreateAuthorAPI {
//    CreateUserAPI author = new CreateUserAPI();

    public void createAuthor(int id, String email){
        given()
                .baseUri("http://35.205.170.236/api/v1/authors/AlinaUserNameTest"+id)
                .auth().basic(email,"testare1234")
                .contentType("application/json")
                .body("{\"firstName\":\"Mark\",\"lastName\":\"Twain\",\"id\":102}")
                .post()
                .getBody().prettyPrint();
    }
public String generateAuthor(){
        return "Mark "+"Twain";
}

}
