package API;

import io.restassured.response.ResponseBody;

import static io.restassured.RestAssured.given;

public class ViewBookAPI {
    public void viewBookResponse(int id, String email, String userName){
        ResponseBody response = given()
                .baseUri("http://35.205.170.236/api/v1/books/"+ userName+"/102")
                .auth().basic(email, "testare1234")
                .contentType("application/json")
                .body("{\n" +
                        "    \"name\": \"TestareAutomata\",\n" +
                        "    \"total\": \"2\",\n" +
                        "    \"available\": \"2\",\n" +
                        "    \"authors\": \"102\",\n" +
                        "    \"id\": 102\n" +
                        "}"
                )
                .get();
        String myResponse = response.asString();
        System.out.println(myResponse);
        //  Assert.assertEquals(myResponse,"{\"id\":102,\"name\":\"TestareAutomata\",\"total\":\"2\",\"available\":\"2\",\"authors\":\"102\",\"sandbox\":\"AlinaUserNameTest75463\",\"created_at\":\"2022-10-26 13:02:39\",\"updated_at\":\"2022-10-26 13:02:40\"}");
    }
}
